package com.sivajavatechie.sonarqube.ant;


public class SonarQubeAnt {

	public static void main(String[] args) {

		System.out.println("Welcome to Ant Project");
		displayMessage();		
	}
		
	public static void displayMessage() {
		System.out.println("Welcome to SonarQube Report for Ant Project");
	}

}
